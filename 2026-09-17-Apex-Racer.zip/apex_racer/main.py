"""Run with python main.py. All asset paths are relative to this project."""
import argparse
import logging


def main():
    parser = argparse.ArgumentParser(description="APEX / Python driving sandbox")
    parser.add_argument("--headless", action="store_true", help="Run without a window")
    parser.add_argument("--steps", type=int, default=600, help="Headless simulation steps")
    parser.add_argument("--screenshot", help="Render one frame offscreen to this PNG path")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    from racing.game import RacingGame
    game = RacingGame(headless=args.headless, offscreen=bool(args.screenshot))
    if args.headless or args.screenshot:
        try:
            for _ in range(args.steps):
                game.simulate(1 / 120)
            if args.screenshot:
                game.update_presentation(1.0)
                # Run render-pipeline tasks once so camera/shadow shader inputs
                # are populated before manual offscreen frames.
                game.taskMgr.step()
                for _ in range(4):
                    game.graphicsEngine.renderFrame()
                from panda3d.core import Filename
                game.win.saveScreenshot(Filename.fromOsSpecific(args.screenshot))
            print(f"Simulation complete: {game.car.position}, {game.car.speed_kmh:.1f} km/h")
        finally:
            game.destroy()
    else:
        game.run()


if __name__ == "__main__":
    main()
