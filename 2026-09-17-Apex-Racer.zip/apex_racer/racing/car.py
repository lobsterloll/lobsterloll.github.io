"""Rear-wheel-drive vehicle: real rigid-body motion, raycast suspension."""
import json
import math
import logging
from panda3d.core import Point3, Vec3, Vec4, TransformState, Material
from panda3d.bullet import BulletRigidBodyNode, BulletBoxShape, BulletVehicle, ZUp
from .config import TUNING, SURFACES, CAR_MASK, ASSETS
from .geometry import box, smooth_loft, wheel_mesh
from .assets import load_optional


def approach(value, target, amount):
    return value + max(-amount, min(amount, target-value))


class Car:
    def __init__(self, render, loader, world, track):
        self.render, self.world, self.track = render, world, track
        self.tuning = TUNING
        self.body = BulletRigidBodyNode("car")
        self.body.setMass(TUNING.mass)
        # Raise collision geometry above the COM for stable but visible body roll.
        self.body.addShape(BulletBoxShape(Vec3(0.83,1.85,0.36)),
                           TransformState.makePos(Point3(0,0,0.38)))
        self.body.setDeactivationEnabled(False)
        self.body.setCcdMotionThreshold(0.5)
        self.body.setCcdSweptSphereRadius(0.28)
        self.body.setAngularDamping(0.12)
        self.node = render.attachNewNode(self.body)
        self.node.setCollideMask(CAR_MASK)
        world.attachRigidBody(self.body)
        self.vehicle = BulletVehicle(world,self.body)
        self.vehicle.setCoordinateSystem(ZUp)
        world.attachVehicle(self.vehicle)
        self.visual = self.node.attachNewNode("body_visual")
        self.use_imported_wheels = False
        self.imported_wheel_spinners = []
        self.imported_wheel_steerers = []
        self.wheel_spin_degrees = 0.0
        self.load_visual(loader)
        self.wheels, self.connections, self.wheel_nodes = [], [], []
        for x,y,front in ((-0.89,1.22,True),(0.89,1.22,True),(-0.89,-1.20,False),(0.89,-1.20,False)):
            wheel_node = render.attachNewNode("wheel")
            if not self.use_imported_wheels:
                wheel_mesh(TUNING.wheel_radius).reparentTo(wheel_node)
            wheel = self.vehicle.createWheel()
            wheel.setNode(wheel_node.node())
            connection = Point3(x,y,0.25)
            wheel.setChassisConnectionPointCs(connection)
            wheel.setFrontWheel(front)
            wheel.setWheelDirectionCs(Vec3(0,0,-1))
            wheel.setWheelAxleCs(Vec3(1,0,0))
            wheel.setWheelRadius(TUNING.wheel_radius)
            wheel.setMaxSuspensionTravelCm(25)
            wheel.setSuspensionStiffness(TUNING.suspension_stiffness)
            wheel.setWheelsDampingRelaxation(3.0)
            wheel.setWheelsDampingCompression(4.5)
            wheel.setMaxSuspensionForce(12000)
            wheel.setFrictionSlip(SURFACES["asphalt"].grip)
            wheel.setRollInfluence(TUNING.roll_influence)
            self.wheels.append(wheel)
            self.connections.append(connection)
            self.wheel_nodes.append(wheel_node)
        # createWheel can reallocate Bullet's internal wheel array. Reacquire
        # wrappers only after ALL wheels exist, otherwise cached references can
        # point at freed memory and cause intermittent native renderer crashes.
        self.wheels = [self.vehicle.getWheel(i) for i in range(4)]
        self.steering = 0.0
        self.throttle = 0.0
        self.brake_input = 0.0
        self.surface = "AIRBORNE"
        self.wheel_surfaces = [None]*4
        self.reset(*track.spawn)

    def load_visual(self, loader):
        model = load_optional(loader,"car")
        if model is not None:
            try:
                path = ASSETS / "car.json"
                options = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
                # Rotate BEFORE bounds fitting. The car must face +Y after this rotation.
                model.setHpr(*options.get("hpr",[0,0,0]))
                model.reparentTo(self.visual)
                # Preserve the GLB's own detailed tire/rim geometry. The source
                # stores all four wheels in one group, so split its direct mesh
                # children into four pivots before flattening the body.
                baked_wheels = model.find("**/Wheel1A_3D")
                wheel_roots = []
                if not baked_wheels.isEmpty():
                    source = baked_wheels.find("**/Combined3DWheel_3DWheel_Front_L Instance1_Src4")
                    centers = ((0.725,-1.1964,0.345),(-0.725,-1.1964,0.345),
                               (0.708,1.256,0.362),(-0.708,1.256,0.362))
                    if not source.isEmpty():
                        wheel_roots = [model.attachNewNode(f"porsche_wheel_{index}")
                                       for index in range(4)]
                        for root,center in zip(wheel_roots,centers):
                            root.setPos(*center)
                        steerers = [root.attachNewNode("steer") for root in wheel_roots]
                        spinners = [steer.attachNewNode("spin") for steer in steerers]
                        for child in [source.getChild(index) for index in range(source.getNumChildren())]:
                            position = child.getPos(model)
                            closest = min(range(4),key=lambda index:
                                          (position.x-centers[index][0])**2+
                                          (position.y-centers[index][1])**2+
                                          (position.z-centers[index][2])**2)
                            child.wrtReparentTo(spinners[closest])
                        baked_wheels.removeNode()
                        self.use_imported_wheels = True
                        self.imported_wheel_spinners = spinners
                        self.imported_wheel_steerers = steerers
                low, high = model.getTightBounds(self.visual)
                size = high-low
                if size.y <= 0.001:
                    raise ValueError("Car has no measurable length")
                scale = float(options.get("length",3.9)) / size.y
                if not math.isfinite(scale) or scale <= 0:
                    raise ValueError("Car length must be positive")
                model.setScale(scale)
                model.setPos(-(low.x+high.x)*scale/2,-(low.y+high.y)*scale/2,0.05-low.z*scale)
                # Detach the separated wheels, keeping their final GLB material,
                # size and position. Flatten only the static body for performance.
                for root in wheel_roots:
                    root.wrtReparentTo(self.visual)
                model.flattenStrong()
                return
            except Exception as exc:
                logging.warning("Custom car rejected: %s; using primitives",exc)
                model.removeNode()
        # Original rounded GT silhouette: hand-authored smooth sections create
        # a low nose, curved shoulders, muscular rear haunches and long tail.
        body = smooth_loft("aurelia_gt_body",[
            (-2.10,0.58,0.20,0.48),(-1.92,0.81,0.15,0.65),
            (-1.55,0.98,0.12,0.74),(-0.92,1.04,0.11,0.78),
            (-0.20,1.03,0.11,0.76),(0.55,1.00,0.12,0.73),
            (1.20,0.96,0.14,0.66),(1.72,0.83,0.17,0.54),(2.12,0.54,0.23,0.38),
        ],(0.72,0.045,0.018,1),24)
        body.reparentTo(self.visual)
        paint=Material("metallic_red_paint")
        # Automotive clear-coat approximation: enough metal for sharp sun
        # highlights, with diffuse paint left to reflect the blue sky fill.
        paint.setBaseColor(Vec4(0.92,0.028,0.012,1)); paint.setMetallic(0.52); paint.setRoughness(0.16)
        paint.setSpecular(Vec4(1.0,0.82,0.75,1))
        body.setMaterial(paint,1)
        cabin = smooth_loft("aurelia_gt_canopy",[
            (-0.96,0.27,0.66,0.78),(-0.62,0.50,0.67,1.05),
            (-0.15,0.61,0.68,1.28),(0.34,0.59,0.67,1.30),
            (0.78,0.47,0.66,1.08),(1.00,0.25,0.65,0.79),
        ],(0.012,0.025,0.045,1),20)
        cabin.reparentTo(self.visual)
        glass=Material("smoked_glass")
        glass.setBaseColor(Vec4(0.018,0.035,0.052,1)); glass.setMetallic(0.18); glass.setRoughness(0.10)
        cabin.setMaterial(glass,1)
        for x in (-0.61,0.61):
            lamp=smooth_loft("headlight",[
                (1.83,0.14,0.38,0.47),(2.10,0.18,0.39,0.47),
            ],(1,0.94,0.65,1),12)
            lamp.reparentTo(self.visual)
            lamp.setX(x)
            tail=smooth_loft("tail_light",[
                (-2.10,0.19,0.39,0.48),(-1.87,0.23,0.40,0.48),
            ],(0.72,0.015,0.01,1),12)
            tail.reparentTo(self.visual)
            tail.setX(x)
        stripe=smooth_loft("center_stripe",[
            (-1.82,0.13,0.64,0.66),(-0.84,0.14,0.77,0.79),
            (0.48,0.14,0.75,0.77),(1.72,0.12,0.59,0.61),
        ],(0.96,0.76,0.18,1),12)
        stripe.reparentTo(self.visual)
        diffuser=smooth_loft("rear_diffuser",[
            (-2.13,0.70,0.16,0.30),(-1.92,0.75,0.17,0.31),
        ],(0.025,0.03,0.035,1),18)
        diffuser.reparentTo(self.visual)
        for x in (-0.60,0.60):
            mirror=smooth_loft("mirror",[
                (-0.12,0.13,0.85,0.95),(0.14,0.17,0.86,0.96),
            ],(0.035,0.045,0.055,1),12)
            mirror.reparentTo(self.visual); mirror.setX(x*1.42)
            mount=smooth_loft("spoiler_mount",[
                (-0.04,0.032,0.00,0.20),(0.04,0.035,0.00,0.20),
            ],(0.025,0.03,0.035,1),10)
            mount.reparentTo(self.visual); mount.setPos(x,-1.67,0.82)
        spoiler=smooth_loft("rear_spoiler",[
            (-0.18,0.88,0.00,0.08),(0.18,0.88,0.00,0.08),
        ],(0.02,0.025,0.032,1),16)
        spoiler.reparentTo(self.visual); spoiler.setPos(0,-1.67,1.04)

    @property
    def position(self):
        return self.node.getPos(self.render)

    @property
    def speed_kmh(self):
        return self.body.getLinearVelocity().length()*3.6

    @property
    def forward_speed(self):
        return self.body.getLinearVelocity().dot(self.node.getQuat(self.render).getForward())

    def reset(self, position, heading):
        self.node.setPos(position)
        self.node.setHpr(heading,0,0)
        self.body.setLinearVelocity(Vec3(0))
        self.body.setAngularVelocity(Vec3(0))
        self.body.clearForces()
        self.body.setActive(True)
        self.vehicle.resetSuspension()
        self.steering = self.throttle = self.brake_input = 0.0
        for i in range(4):
            self.vehicle.applyEngineForce(0,i)
            self.vehicle.setBrake(0,i)
            self.vehicle.setSteeringValue(0,i)

    def update(self, dt, controls):
        tuning = self.tuning
        velocity = self.body.getLinearVelocity()
        speed = velocity.length()
        signed_speed = self.forward_speed
        # Cast at all four wheel mounts, along the chassis suspension direction.
        # Separate world mask prevents the rays from hitting our own body.
        down = self.node.getQuat(self.render).xform(Vec3(0,0,-1))
        self.wheel_surfaces = []
        for point,wheel in zip(self.connections,self.wheels):
            start = self.render.getRelativePoint(self.node,point)
            reach = wheel.getSuspensionRestLength()+tuning.wheel_radius+0.25
            self.wheel_surfaces.append(self.track.surface_at(start,start+down*reach))
        ground = [SURFACES[s] for s,wheel in zip(self.wheel_surfaces,self.wheels)
                  if s is not None and wheel.getRaycastInfo().isInContact()]
        surface_key = next((s for s in ("grass","dirt","asphalt","wall") if s in self.wheel_surfaces),None)
        self.surface = SURFACES[surface_key].label if surface_key else "AIRBORNE"
        drive_factor = sum(s.drive_factor for s in ground)/len(ground) if ground else 1.0
        rolling = sum(s.rolling for s in ground)/len(ground) if ground else 0.0
        handbrake = controls.held("handbrake")
        for i,wheel in enumerate(self.wheels):
            profile = SURFACES.get(self.wheel_surfaces[i],SURFACES["asphalt"])
            # Rear-only grip reduction is immediate, restored upon release.
            wheel.setFrictionSlip(profile.grip*(tuning.handbrake_grip_factor if handbrake and i>=2 else 1))
        steer_input = int(controls.held("left"))-int(controls.held("right"))
        limit = tuning.steering_low+(tuning.steering_high-tuning.steering_low)*min(speed/50,1)
        self.steering = approach(self.steering,steer_input*limit,tuning.steering_rate*dt)
        for i in (0,1):
            self.vehicle.setSteeringValue(self.steering,i)
        if self.imported_wheel_spinners:
            # Imported wheel meshes use +X axles. Rotate them from physical
            # travel while the front pivots follow steering input.
            self.wheel_spin_degrees -= math.degrees(signed_speed/tuning.wheel_radius)*dt
            for index,spinner in enumerate(self.imported_wheel_spinners):
                spinner.setP(self.wheel_spin_degrees)
                self.imported_wheel_steerers[index].setH(math.degrees(self.steering) if index < 2 else 0)
        forward, backward = controls.held("forward"), controls.held("backward")
        # S / Down brakes while moving forward, then becomes reverse once the
        # car is nearly stopped. W behaves symmetrically if rolling backward.
        target, brake_target = 0.0, 0.0
        if forward and backward:
            brake_target = 1.0
        elif forward:
            if signed_speed < -0.6:
                brake_target = 1.0
            else:
                target = 1.0
        elif backward:
            if signed_speed > 0.6:
                brake_target = 1.0
            else:
                target = -1.0
        brake_rate = tuning.brake_rise if brake_target > self.brake_input else tuning.brake_release
        self.brake_input = approach(self.brake_input,brake_target,brake_rate*dt)
        brake = tuning.brake*self.brake_input
        # Brake commands cancel drive immediately; throttle itself ramps smoothly.
        self.throttle = approach(self.throttle,target,3.5*dt) if self.brake_input < 0.02 else 0.0
        engine = 0.0
        if self.throttle > 0:
            taper=max(0.0,min(1.0,(tuning.max_forward_speed-max(signed_speed,0))/8))
            engine=min(tuning.engine_force,tuning.engine_power/max(speed,1))*self.throttle*taper
        elif self.throttle < 0:
            taper=max(0.0,min(1.0,(tuning.max_reverse_speed-max(-signed_speed,0))/3))
            engine=tuning.reverse_force*self.throttle*taper
        for i in range(4):
            self.vehicle.applyEngineForce(engine*drive_factor/2 if i>=2 and not handbrake else 0,i)
            # Brake bias keeps the rear axle from locking first. Space remains
            # the deliberate rear-wheel lock-up control for drifting.
            service_brake = brake*(tuning.brake_front_bias if i<2 else 2-tuning.brake_front_bias)
            self.vehicle.setBrake(max(service_brake,tuning.handbrake if handbrake and i>=2 else 0),i)
        if speed > 0.01:
            # Momentum is never overwritten: grass slows the car through force.
            resistance = velocity*(-tuning.aerodynamic_drag*speed)
            if ground:
                resistance += Vec3(velocity.x,velocity.y,0)*(-rolling)
                forward_axis = self.node.getQuat(self.render).getForward()
                right_axis = self.node.getQuat(self.render).getRight()
                lateral_speed = velocity.dot(right_axis)
                # Electronic stability assist acts only when the handbrake is
                # released. It damps a skid using force, so grass still feels
                # loose and Space still initiates a real drift.
                stability = tuning.traction_stability + tuning.brake_stability*self.brake_input
                resistance += right_axis*(-lateral_speed*self.tuning.mass*stability*drive_factor)
                if self.brake_input > 0.0 and abs(signed_speed) > 0.15:
                    # The main service-brake force acts through the centre of
                    # mass. This gives a firm S/Down pedal without Bullet's
                    # wheel torque pitching the chassis over at high speed.
                    direction = math.copysign(1.0,signed_speed)
                    resistance += forward_axis*(-direction*self.tuning.mass*
                                                tuning.brake_deceleration*self.brake_input*drive_factor)
                if abs(self.throttle) < 0.01 and self.brake_input < 0.01:
                    resistance += forward_axis*(-math.copysign(tuning.engine_braking,signed_speed))
            self.body.applyCentralForce(resistance)
