"""Ordered, directional gate crossings measured in simulation time."""
from dataclasses import dataclass
from panda3d.core import Point3, Vec3


@dataclass
class Gate:
    center: Point3
    forward: Vec3
    half_width: float = 9.0
    half_height: float = 3.0

    def crossed(self, previous, current):
        before = (previous - self.center).dot(self.forward)
        after = (current - self.center).dot(self.forward)
        if not (before < 0 <= after):
            return False
        hit = previous + (current - previous) * (-before / (after - before))
        side = Vec3(self.forward.y, -self.forward.x, 0)
        return (abs((hit - self.center).dot(side)) <= self.half_width
                and abs(hit.z - self.center.z) <= self.half_height)


class RaceManager:
    def __init__(self, gates, position):
        self.gates = gates
        self.previous = Point3(position)
        self.next_gate = 0
        self.started = False
        self.completed = 0
        self.elapsed = 0.0
        self.last = None
        self.best = None
        self.valid = True

    def reset_position(self, position):
        # A reset abandons this lap; keep completed results but require a new start.
        self.previous = Point3(position)
        self.next_gate = 0
        self.started = False
        self.elapsed = 0.0
        self.valid = True

    def update(self, position, dt, on_course=True):
        if self.started:
            self.elapsed += dt
            self.valid = self.valid and on_course
        gate = self.gates[self.next_gate]
        if gate.crossed(self.previous, position):
            if self.next_gate == 0:
                if self.started and self.valid:
                    self.completed += 1
                    self.last = self.elapsed
                    self.best = self.last if self.best is None else min(self.best, self.last)
                self.started = True
                self.elapsed = 0.0
                self.valid = True
            self.next_gate = (self.next_gate + 1) % len(self.gates)
        self.previous = Point3(position)


def time_text(seconds):
    if seconds is None:
        return "--:--.---"
    minutes, seconds = divmod(seconds, 60)
    return f"{int(minutes):02d}:{seconds:06.3f}"
