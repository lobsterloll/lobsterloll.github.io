"""Small procedural meshes; no downloaded art is needed to play."""
import math
from panda3d.core import (Geom, GeomNode, GeomTriangles, GeomVertexData,
                          GeomVertexFormat, GeomVertexWriter, NodePath, Vec3)


def mesh(name, triangles, color):
    data = GeomVertexData(name, GeomVertexFormat.getV3n3t2(), Geom.UHStatic)
    vertex = GeomVertexWriter(data, "vertex")
    normal = GeomVertexWriter(data, "normal")
    texcoord = GeomVertexWriter(data, "texcoord")
    primitive = GeomTriangles(Geom.UHStatic)
    for triangle in triangles:
        a, b, c = [Vec3(*p) for p in triangle]
        n = (b - a).cross(c - a)
        n.normalize()
        start = vertex.getWriteRow()
        for p in (a, b, c):
            vertex.addData3(p)
            normal.addData3(n)
            # World/projected UVs make procedural terrain tile consistently.
            # Untextured objects simply ignore this channel.
            texcoord.addData2(p.x, p.y)
        primitive.addVertices(start, start + 1, start + 2)
    geom = Geom(data)
    geom.addPrimitive(primitive)
    node = GeomNode(name)
    node.addGeom(geom)
    result = NodePath(node)
    result.setColor(*color)
    return result


def loft(name, sections, color):
    """Create a chamfered, closed body shell from y/width/bottom/top sections."""
    rings = []
    for y, width, bottom, top in sections:
        shoulder = top - min(0.14, (top-bottom)*0.22)
        rings.append([
            (-width,y,bottom), (width,y,bottom),
            (width,y,shoulder), (width*0.68,y,top),
            (-width*0.68,y,top), (-width,y,shoulder),
        ])
    triangles = []
    count = len(rings[0])
    for i in range(len(rings)-1):
        for j in range(count):
            a,b = rings[i][j],rings[i][(j+1)%count]
            c,d = rings[i+1][(j+1)%count],rings[i+1][j]
            triangles.extend(((a,b,c),(a,c,d)))
    front, rear = rings[-1],rings[0]
    front_center = (0,front[0][1],sum(p[2] for p in front)/count)
    rear_center = (0,rear[0][1],sum(p[2] for p in rear)/count)
    for j in range(count):
        triangles.append((front_center,front[j],front[(j+1)%count]))
        triangles.append((rear_center,rear[(j+1)%count],rear[j]))
    return mesh(name,triangles,color)


def smooth_loft(name, sections, color, sides=20):
    """A smoothly shaded oval section body for rounded vehicle panels."""
    data = GeomVertexData(name, GeomVertexFormat.getV3n3t2(), Geom.UHStatic)
    vertex = GeomVertexWriter(data, "vertex")
    normal = GeomVertexWriter(data, "normal")
    texcoord = GeomVertexWriter(data, "texcoord")
    primitive = GeomTriangles(Geom.UHStatic)
    for row,(y,width,bottom,top) in enumerate(sections):
        center, height = (bottom+top)*0.5, max((top-bottom)*0.5,0.001)
        for column in range(sides):
            angle = math.tau*column/sides
            x, z = width*math.cos(angle), center+height*math.sin(angle)
            n = Vec3(math.cos(angle)/max(width,0.001),0,math.sin(angle)/height)
            n.normalize()
            vertex.addData3(x,y,z); normal.addData3(n)
            texcoord.addData2(column/sides,row/max(len(sections)-1,1))
    for row in range(len(sections)-1):
        for column in range(sides):
            next_column = (column+1)%sides
            a, b = row*sides+column, row*sides+next_column
            c, d = (row+1)*sides+next_column, (row+1)*sides+column
            primitive.addVertices(a,b,c); primitive.addVertices(a,c,d)
    geom = Geom(data); geom.addPrimitive(primitive)
    node = GeomNode(name); node.addGeom(geom)
    result = NodePath(node); result.setColor(*color)
    return result


def box(name, half, color):
    x, y, z = half
    faces = [
        [(-x,-y,-z),(-x,y,-z),(x,y,-z),(x,-y,-z)],
        [(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)],
        [(-x,-y,-z),(x,-y,-z),(x,-y,z),(-x,-y,z)],
        [(x,y,-z),(-x,y,-z),(-x,y,z),(x,y,z)],
        [(-x,y,-z),(-x,-y,-z),(-x,-y,z),(-x,y,z)],
        [(x,-y,-z),(x,y,-z),(x,y,z),(x,-y,z)],
    ]
    return mesh(name, [t for a,b,c,d in faces for t in [(a,b,c),(a,c,d)]], color)


def ring(name, inner, outer, color, z=0.0, segments=192):
    triangles = []
    for i in range(segments):
        a, b = math.tau * i / segments, math.tau * (i + 1) / segments
        p = [(r * math.cos(t), r * math.sin(t), z)
             for r,t in [(inner,a),(outer,a),(outer,b),(inner,b)]]
        triangles.extend([(p[0],p[1],p[2]),(p[0],p[2],p[3])])
    return mesh(name, triangles, color)


def ribbon(name, centerline, half_width, color, z_offset=0.0):
    """Build a closed road-like strip around a sampled 3D centerline."""
    triangles = []
    count = len(centerline)
    edges = []
    for i, point in enumerate(centerline):
        previous = Vec3(centerline[(i - 1) % count])
        following = Vec3(centerline[(i + 1) % count])
        tangent = following - previous
        tangent.z = 0
        tangent.normalize()
        right = Vec3(tangent.y, -tangent.x, 0)
        center = Vec3(point) + Vec3(0, 0, z_offset)
        edges.append((center - right * half_width, center + right * half_width))
    for i in range(count):
        left, right = edges[i]
        next_left, next_right = edges[(i + 1) % count]
        triangles.extend(((left, right, next_right), (left, next_right, next_left)))
    return mesh(name, triangles, color)


def patterned_band(name, centerline, inner_offset, outer_offset,
                   color_a, color_b=None, pattern_length=3, z_offset=0.01):
    """A closed curve-following strip with seamless alternating color sections."""
    groups = [[], []]
    count = len(centerline)
    for i in range(count):
        points = []
        for index in (i, (i + 1) % count):
            previous = Vec3(centerline[(index - 1) % count])
            following = Vec3(centerline[(index + 1) % count])
            tangent = following - previous
            tangent.z = 0
            tangent.normalize()
            right = Vec3(tangent.y, -tangent.x, 0)
            center = Vec3(centerline[index]) + Vec3(0, 0, z_offset)
            points.append((center + right * inner_offset,
                           center + right * outer_offset))
        near, far = points[0]
        next_near, next_far = points[1]
        group = (i // pattern_length) % 2
        if color_b is None and group == 1:
            continue
        if outer_offset >= inner_offset:
            groups[group].extend(((near, far, next_far), (near, next_far, next_near)))
        else:
            groups[group].extend(((near, next_far, far), (near, next_near, next_far)))
    root = NodePath(name)
    if groups[0]:
        mesh(name + "_a", groups[0], color_a).reparentTo(root)
    if color_b is not None and groups[1]:
        mesh(name + "_b", groups[1], color_b).reparentTo(root)
    return root


def patterned_wall(name, centerline, offset, height, color_a, color_b,
                   pattern_length=3, z_offset=0.0):
    """A continuous vertical barrier skin; collision remains in simple boxes."""
    groups = [[], []]
    count = len(centerline)
    for i in range(count):
        bases = []
        centers = []
        for index in (i, (i + 1) % count):
            previous = Vec3(centerline[(index - 1) % count])
            following = Vec3(centerline[(index + 1) % count])
            tangent = following - previous
            tangent.z = 0
            tangent.normalize()
            right = Vec3(tangent.y, -tangent.x, 0)
            center = Vec3(centerline[index]) + Vec3(0,0,z_offset)
            centers.append(center)
            bases.append(center + right * offset)
        a, b = bases
        at, bt = a + Vec3(0,0,height), b + Vec3(0,0,height)
        # Keep the visible/collision boundary at a/b. All physical thickness
        # extends away from the road, never invisibly into the racing surface.
        outward = (a+b)*0.5-(centers[0]+centers[1])*0.5
        if outward.lengthSquared() > 0:
            outward.normalize()
        lip = outward * 0.22
        ao, bo, ato, bto = a+lip, b+lip, at+lip, bt+lip
        group = (i // pattern_length) % 2
        groups[group].extend(((a,b,bt),(a,bt,at),
                              (at,bt,bto),(at,bto,ato),
                              (bo,ao,ato),(bo,ato,bto)))
    root = NodePath(name)
    for index, color in enumerate((color_a,color_b)):
        if groups[index]:
            part=mesh(f"{name}_{index}",groups[index],color)
            part.setTwoSided(True)
            part.reparentTo(root)
    return root


def cylinder(name, radius, height, color, segments=16):
    triangles = []
    for i in range(segments):
        a, b = math.tau * i / segments, math.tau * (i + 1) / segments
        lower_a = (radius * math.cos(a), radius * math.sin(a), 0)
        lower_b = (radius * math.cos(b), radius * math.sin(b), 0)
        upper_a = (lower_a[0], lower_a[1], height)
        upper_b = (lower_b[0], lower_b[1], height)
        triangles.extend(((lower_a, lower_b, upper_b), (lower_a, upper_b, upper_a)))
        triangles.extend((((0, 0, 0), lower_b, lower_a), ((0, 0, height), upper_a, upper_b)))
    return mesh(name, triangles, color)


def wheel_mesh(radius, width=0.26):
    # Cylinder axle runs along X; Bullet rotates the parent node each step.
    triangles = []
    for i in range(20):
        a, b = math.tau*i/20, math.tau*(i+1)/20
        points = [(x, radius*math.cos(t), radius*math.sin(t))
                  for x,t in [(-width/2,a),(width/2,a),(width/2,b),(-width/2,b)]]
        triangles.extend([(points[0],points[1],points[2]),(points[0],points[2],points[3])])
        triangles.extend([((-width/2,0,0),points[0],points[3]),
                          ((width/2,0,0),points[2],points[1])])
    result = mesh("tire", triangles, (0.012,0.015,0.019,1))
    result.setTwoSided(True)
    # Five silver spokes make rotation visible even from the chase camera.
    rim = []
    for side in (-width/2-0.004, width/2+0.004):
        for spoke in range(5):
            angle = math.tau * spoke / 5 + math.pi / 10
            radial = (math.cos(angle), math.sin(angle))
            tangent = (-radial[1], radial[0])
            inner, outer, half = radius*0.07, radius*0.62, radius*0.075
            points = []
            for distance, offset in ((inner,-half),(outer,-half),(outer,half),(inner,half)):
                y = radial[0]*distance+tangent[0]*offset
                z = radial[1]*distance+tangent[1]*offset
                points.append((side,y,z))
            rim.extend(((points[0],points[1],points[2]),(points[0],points[2],points[3])))
        for index in range(16):
            a, b = math.tau*index/16, math.tau*(index+1)/16
            rim.append(((side,0,0),(side,radius*0.12*math.cos(a),radius*0.12*math.sin(a)),
                        (side,radius*0.12*math.cos(b),radius*0.12*math.sin(b))))
    mesh("alloy_rim", rim, (0.48,0.52,0.56,1)).reparentTo(result)
    return result
