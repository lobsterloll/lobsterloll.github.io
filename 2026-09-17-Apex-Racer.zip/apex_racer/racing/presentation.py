"""Keyboard bindings, collision-aware chase camera, and HUD."""
import math
from panda3d.core import Point3, Vec3, TextNode, LineSegs
from direct.gui.OnscreenText import OnscreenText
from direct.gui.DirectGui import DirectFrame
from .config import RAY_MASK
from .race import time_text


class Controls:
    KEYS = {"forward":("w","arrow_up"),"backward":("s","arrow_down"),
            "left":("a","arrow_left"),"right":("d","arrow_right"),"handbrake":("space",)}

    def __init__(self, app):
        self.keys = set()
        for bindings in self.KEYS.values():
            for key in bindings:
                app.accept(key,self.set_key,[key,True])
                app.accept(key+"-up",self.set_key,[key,False])
        app.accept("window-event",self.window_event)

    def window_event(self, window):
        if not window.getProperties().getForeground():
            self.keys.clear()  # Never leave throttle stuck after Alt-Tab.

    def set_key(self,key,down):
        if down:
            self.keys.add(key)
        else:
            self.keys.discard(key)

    def held(self,action):
        return any(key in self.keys for key in self.KEYS[action])


class ChaseCamera:
    def __init__(self, app, car, world):
        self.app, self.car, self.world = app,car,world
        self.fov = 64.0
        self.snap = True

    def update(self,dt):
        position = self.car.position
        forward = self.car.node.getQuat().getForward()
        forward.z = 0
        if forward.lengthSquared() < 0.001:
            forward = Vec3(0,1,0)
        forward.normalize()
        speed = self.car.speed_kmh
        target = position+Vec3(0,0,1.1)
        desired = position-forward*(7.5+min(speed/100,2.0))+Vec3(0,0,3.7)
        alpha = 1-math.exp(-6*dt)
        proposed = desired if self.snap else self.app.camera.getPos()+(desired-self.app.camera.getPos())*alpha
        # Test the smoothed location too, so interpolation cannot cut through walls.
        hit=self.world.rayTestClosest(target,proposed,RAY_MASK)
        if hit.hasHit():
            direction=proposed-target
            direction.normalize()
            proposed=hit.getHitPos()-direction*0.35
        self.app.camera.setPos(proposed)
        self.app.camera.lookAt(target+forward*2.2)
        self.fov+=(64+min(speed/180,1)*14-self.fov)*alpha
        self.app.camLens.setFov(self.fov)
        self.snap=False


class HUD:
    def __init__(self,app,track):
        self.app, self.track = app,track
        self.map_left, self.map_right = 0.09,0.56
        self.map_top, self.map_bottom = -0.10,-0.40

        def label(text,x,y,size=0.04,color=(0.85,0.9,0.94,1),parent=None,align=TextNode.ALeft):
            result=OnscreenText(text=text,parent=parent or app.a2dTopLeft,pos=(x,y),
                               scale=size,align=align,fg=color,mayChange=True)
            result.setBin("fixed",110)
            return result

        self._build_map()
        self.lap=label("LAP  1 / 2",0.085,-0.445,0.040,(0.96,0.98,1,1))
        self.timer=label("00:00.000",0.085,-0.495,0.043,(0.96,0.98,1,1))

        self.speed=label("000",-0.075,-0.155,0.135,(0.96,0.98,1,1),app.a2dTopRight,TextNode.ARight)
        label("KM/H",-0.075,-0.215,0.025,(0.96,0.98,1,1),app.a2dTopRight,TextNode.ARight)
        self.position=label("1 / 1",-0.075,-0.295,0.052,(0.96,0.98,1,1),app.a2dTopRight,TextNode.ARight)
        self.help=label("W / UP  Throttle    S / DOWN  Brake + Reverse    SPACE  Handbrake    A / D  Steer    R  Reset",0.06,0.07,
                        0.031,parent=app.a2dBottomLeft)

    def _map_point(self,position):
        min_x,max_x,min_y,max_y = self.map_bounds
        width = max(max_x-min_x,0.001)
        height = max(max_y-min_y,0.001)
        scale = min((self.map_right-self.map_left)/width,(self.map_bottom-self.map_top)/height)
        center_x,center_y = (min_x+max_x)*0.5,(min_y+max_y)*0.5
        map_x = (self.map_left+self.map_right)*0.5+(position.x-center_x)*scale
        map_y = (self.map_top+self.map_bottom)*0.5-(position.y-center_y)*scale
        return map_x,map_y

    def _build_map(self):
        points = list(getattr(self.track,"centerline",[]))
        if len(points) < 2:
            points = [gate.center for gate in self.track.gates]
        self.map_bounds = (min(point.x for point in points),max(point.x for point in points),
                           min(point.y for point in points),max(point.y for point in points))
        lines=LineSegs("track_minimap")
        lines.setColor(0.82,0.87,0.92,1)
        lines.setThickness(2.6)
        x,z=self._map_point(points[0]); lines.moveTo(x,0,z)
        for point in points[1:]:
            x,z=self._map_point(point); lines.drawTo(x,0,z)
        x,z=self._map_point(points[0]); lines.drawTo(x,0,z)
        self.map_line=self.app.a2dTopLeft.attachNewNode(lines.create())
        self.map_line.setBin("fixed",105)
        dot=LineSegs("player_minimap_dot")
        dot.setColor(1,0.20,0.10,1)
        dot.setThickness(5.0)
        radius=0.012
        for index in range(13):
            angle=math.tau*index/12
            point=(radius*math.cos(angle),0,radius*math.sin(angle))
            if index == 0:
                dot.moveTo(*point)
            else:
                dot.drawTo(*point)
        self.player_dot=self.app.a2dTopLeft.attachNewNode(dot.create())
        self.player_dot.setBin("fixed",108)

    def update(self,car,race):
        self.speed.setText(f"{car.speed_kmh:03.0f}")
        self.lap.setText(f"LAP  {min(race.completed+1,2)} / 2")
        self.timer.setText(time_text(race.elapsed))
        map_x,map_z=self._map_point(car.position)
        self.player_dot.setPos(map_x,0,map_z)
