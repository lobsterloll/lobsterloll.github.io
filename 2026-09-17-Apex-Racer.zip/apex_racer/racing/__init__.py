"""Modular Panda3D / Bullet driving game."""
