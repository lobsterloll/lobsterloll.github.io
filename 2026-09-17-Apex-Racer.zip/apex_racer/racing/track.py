"""Static mesh circuit, collision barriers, metadata, and reset locations."""
import json
import math
import logging
from panda3d.core import (Point3, Vec3, Filename, TextureStage, SamplerState,
                          Material, Vec4, CardMaker, TransparencyAttrib)
from panda3d.bullet import BulletRigidBodyNode, BulletBoxShape, BulletTriangleMesh, BulletTriangleMeshShape
from .config import ASSETS, WORLD_MASK, RAY_MASK
from .geometry import box, ribbon, patterned_band, patterned_wall, cylinder
from .assets import load_optional, surface_of
from .race import Gate


class Track:
    def __init__(self, render, loader, world):
        self.render, self.world, self.loader = render, world, loader
        self.root = render.attachNewNode("track")
        self.bodies = []
        self.custom = False
        model = load_optional(loader, "track")
        if model is not None:
            metadata = ASSETS / "track.json"
            if not metadata.exists():
                logging.warning("Custom track requires assets/track.json for gates and spawn; using fallback")
                model.removeNode()
            else:
                try:
                    self.load_custom(model, json.loads(metadata.read_text(encoding="utf-8")))
                    self.custom = True
                except Exception as exc:
                    logging.warning("Invalid custom track: %s; using fallback", exc)
                    for body in self.bodies:
                        world.removeRigidBody(body.node())
                    self.bodies.clear()
                    self.root.removeNode()
                    self.root = render.attachNewNode("track")
        if not self.custom:
            self.build_fallback()

    def collider(self, visual, surface):
        # Each GeomNode is copied with its full transform relative to the scene.
        # This preserves nested translation, rotation and scale in imported models.
        triangle_mesh = BulletTriangleMesh()
        for index in range(visual.node().getNumGeoms()):
            triangle_mesh.addGeom(visual.node().getGeom(index), False,
                                  visual.getTransform(self.render))
        if not triangle_mesh.getNumTriangles():
            return
        body = BulletRigidBodyNode(surface)
        body.addShape(BulletTriangleMeshShape(triangle_mesh, dynamic=False))
        body.setPythonTag("surface", surface)
        node = self.root.attachNewNode(body)
        node.setCollideMask(WORLD_MASK)
        self.world.attachRigidBody(body)
        self.bodies.append(node)

    def solid_box(self, name, position, half, color, heading=0, surface="wall",
                  visible=True):
        body = BulletRigidBodyNode(name)
        body.addShape(BulletBoxShape(Vec3(*half)))
        body.setPythonTag("surface", surface)
        node = self.root.attachNewNode(body)
        node.setPos(*position)
        node.setH(heading)
        node.setCollideMask(WORLD_MASK)
        if visible:
            box(name, half, color).reparentTo(node)
        self.world.attachRigidBody(body)
        self.bodies.append(node)
        return node

    def apply_material(self, node, filename, uv_scale, roughness=0.92,
                       tint=(1,1,1,1)):
        path = ASSETS / "textures" / filename
        if not path.exists():
            return
        texture = self.loader.loadTexture(Filename.fromOsSpecific(str(path)))
        texture.setWrapU(SamplerState.WM_repeat)
        texture.setWrapV(SamplerState.WM_repeat)
        texture.setMinfilter(SamplerState.FT_linear_mipmap_linear)
        texture.setMagfilter(SamplerState.FT_linear)
        texture.setAnisotropicDegree(8)
        node.setTexture(texture,1)
        node.setTexScale(TextureStage.getDefault(),uv_scale,uv_scale)
        node.setColor(1,1,1,1)
        material=Material()
        material.setBaseColor(Vec4(*tint))
        material.setRoughness(roughness)
        material.setMetallic(0.0)
        node.setMaterial(material,1)

    def build_fallback(self):
        self.road_half_width = 7.4
        # Control points form a varied club circuit: two fast sweepers, a tight
        # northern hairpin, an esses section and a long start/finish straight.
        controls = [
            Point3(42,-62,0), Point3(82,-43,0), Point3(94,-5,0),
            Point3(72,35,0), Point3(33,60,0), Point3(-4,52,0),
            Point3(-38,72,0), Point3(-78,57,0), Point3(-96,18,0),
            Point3(-78,-20,0), Point3(-92,-56,0), Point3(-53,-76,0),
            Point3(-14,-62,0), Point3(8,-34,0), Point3(25,-64,0),
        ]
        self.centerline = self._sample_closed_spline(controls, 14)
        grass = self.solid_box("grass_field", (0,0,-0.42), (125,105,0.4),
                               (1,1,1,1), surface="grass")
        self.apply_material(grass.find("**/+GeomNode"),"grass_albedo.png",0.075,1.0,
                            (0.62,0.76,0.58,1))
        road = ribbon("asphalt_road", self.centerline, self.road_half_width,
                      (1,1,1,1), 0.0)
        road.reparentTo(self.root)
        self.apply_material(road,"asphalt_albedo.png",0.17,0.94,(0.46,0.48,0.52,1))
        self.collider(road,"asphalt")

        # Painted shoulders sit just above the collision mesh. Alternating curb
        # blocks make corner direction readable at speed.
        self._build_curbs_and_barriers()
        self._build_lane_markers()
        self._build_start_finish()
        self._build_scenery()

        gate_indices = [0, 36, 72, 108, 144, 180]
        self.gates = [self._gate_at(index) for index in gate_indices]
        start = self.centerline[-4]
        tangent = self._tangent(-4)
        self.spawn = (Point3(start.x, start.y, start.z + 1.0), self._heading(tangent))

    @staticmethod
    def _sample_closed_spline(points, steps):
        """Uniform Catmull-Rom interpolation through a closed list of points."""
        result = []
        for i in range(len(points)):
            p0, p1 = points[i-1], points[i]
            p2, p3 = points[(i+1) % len(points)], points[(i+2) % len(points)]
            for step in range(steps):
                t = step / steps
                t2, t3 = t*t, t*t*t
                result.append(Point3(*[
                    0.5*((2*p1[axis])+(-p0[axis]+p2[axis])*t+
                         (2*p0[axis]-5*p1[axis]+4*p2[axis]-p3[axis])*t2+
                         (-p0[axis]+3*p1[axis]-3*p2[axis]+p3[axis])*t3)
                    for axis in range(3)]))
        return result

    def _tangent(self, index):
        count = len(self.centerline)
        tangent = self.centerline[(index+1) % count] - self.centerline[(index-1) % count]
        tangent.z = 0
        tangent.normalize()
        return tangent

    @staticmethod
    def _heading(tangent):
        return math.degrees(math.atan2(-tangent.x, tangent.y))

    def _gate_at(self, index):
        point = self.centerline[index % len(self.centerline)]
        return Gate(Point3(point), self._tangent(index), self.road_half_width + 0.8, 4.5)

    def _build_lane_markers(self):
        marker = patterned_band("lane_dash",self.centerline,-0.075,0.075,
                                (0.76,0.78,0.78,1),None,4,0.007)
        marker.reparentTo(self.root)

    def _build_curbs_and_barriers(self):
        count = len(self.centerline)
        for side in (-1,1):
            curb=patterned_band("curb",self.centerline,
                                side*(self.road_half_width-0.55),
                                side*(self.road_half_width+0.10),
                                (0.82,0.055,0.035,1),(0.88,0.87,0.82,1),3,0.009)
            curb.reparentTo(self.root)
            wall=patterned_wall("barrier_visual",self.centerline,
                                side*(self.road_half_width+3.2),1.16,
                                (0.19,0.22,0.24,1),(0.78,0.80,0.78,1),4,0.0)
            wall.reparentTo(self.root)
            # Use these exact triangles for physics. This eliminates the inward
            # corners created by approximate rotated box colliders.
            for visual in wall.findAllMatches("**/+GeomNode"):
                self.collider(visual,"wall")

    def _build_start_finish(self):
        point = self.centerline[0]
        tangent = self._tangent(0)
        right = Vec3(tangent.y,-tangent.x,0)
        heading = self._heading(tangent)
        for lateral in range(-7,8):
            for longitudinal in range(2):
                tile = box("finish",(0.5,0.5,0.004),
                           (0.92,0.92,0.90,1) if (lateral+longitudinal)%2 else (0.018,0.022,0.026,1))
                tile.reparentTo(self.root)
                tile.setPos(point + right*(lateral+0.5) + tangent*(longitudinal-0.5) + Vec3(0,0,0.006))
                tile.setH(heading)

    def _build_scenery(self):
        # Pit building and grandstand anchor the start area.
        self.solid_box("pit_building",(48,-78,2.3),(18,4.5,2.5),(0.42,0.45,0.47,1),surface="wall")
        for x in range(34,63,4):
            window=box("pit_window",(1.45,0.04,0.65),(0.06,0.16,0.23,1))
            window.reparentTo(self.root); window.setPos(x,-73.46,2.6)
        for row in range(5):
            stand=box("grandstand",(18,1.4,0.35),(0.24+row*0.035,0.27,0.29,1))
            stand.reparentTo(self.root); stand.setPos(-48,-91+row*1.5,0.35+row*0.65)
        # Alpha-cut photographic conifers provide dense, natural trackside
        # foliage while keeping the circuit lightweight enough for real-time play.
        tree_texture_path = ASSETS / "foliage" / "conifer_tree.png"
        tree_texture = self.loader.loadTexture(Filename.fromOsSpecific(str(tree_texture_path)))
        tree_texture.setMinfilter(SamplerState.FT_linear_mipmap_linear)
        tree_texture.setMagfilter(SamplerState.FT_linear)
        tree_texture.setAnisotropicDegree(8)
        tree_positions=[(-118,49),(-108,44),(-116,-24),(-102,-18),(-78,96),(-69,89),
                        (-35,96),(-22,88),(10,89),(24,78),(58,78),(74,68),
                        (115,34),(105,23),(120,-38),(110,-48),(94,-88),(79,-79),
                        (14,-96),(0,-88),(-112,-83),(-119,-69),(-18,22),(-4,16),
                        (42,15),(55,5),(-58,31),(-67,18)]
        for index,(x,y) in enumerate(tree_positions):
            card=CardMaker("conifer")
            card.setFrame(-0.5,0.5,0,1)
            tree=self.root.attachNewNode(card.generate())
            tree.setTexture(tree_texture,1)
            tree.setTransparency(TransparencyAttrib.MAlpha)
            tree.setTwoSided(True)
            tree.setBillboardPointEye()
            height=8.5+(index%5)*1.25
            tree.setScale(height*0.52,1,height)
            tree.setPos(x,y,0)
            tree.setBin("transparent",15)
        for x,y in ((105,5),(-106,8),(-72,-84),(75,58)):
            post=box("marshal_post",(2.2,1.5,1.5),(0.96,0.48,0.06,1))
            post.reparentTo(self.root); post.setPos(x,y,1.5)

    def load_custom(self, model, data):
        model.reparentTo(self.root)
        scale = float(data.get("scale",1))
        if not math.isfinite(scale) or scale <= 0:
            raise ValueError("scale must be positive")
        model.setScale(scale)
        model.setHpr(*data.get("hpr",[0,0,0]))
        model.setPos(*data.get("position",[0,0,0]))
        self.spawn = (Point3(*data["spawn"]["position"]), float(data["spawn"]["heading"]))
        self.gates = []
        for record in data["gates"]:
            forward = Vec3(*record["forward"])
            forward.z = 0
            if forward.length() < 0.001:
                raise ValueError("Gate forward direction must be nonzero")
            forward.normalize()
            gate = Gate(Point3(*record["center"]), forward,
                        float(record.get("half_width",9)),float(record.get("half_height",3)))
            if gate.half_width <= 0 or gate.half_height <= 0:
                raise ValueError("Gate dimensions must be positive")
            self.gates.append(gate)
        if len(self.gates) < 3:
            raise ValueError("Use at least three ordered gates; gate 0 is start/finish")
        for visual in model.findAllMatches("**/+GeomNode"):
            if visual.getNetTag("no_collision") != "1":
                self.collider(visual, surface_of(visual, model))
        if not self.bodies:
            raise ValueError("No triangle geometry found")

    def surface_at(self, start, end):
        hit = self.world.rayTestClosest(start,end,RAY_MASK)
        if hit.hasHit():
            node = hit.getNode()
            return node.getPythonTag("surface") if node.hasPythonTag("surface") else "asphalt"
        return None

    def on_course(self, position):
        if not self.custom:
            return min((position.x-p.x)**2+(position.y-p.y)**2 for p in self.centerline) <= (self.road_half_width+1.2)**2
        # Custom tracks use ordered gates. Add gates wherever shortcutting is possible.
        return True

    def reset_pose(self, position):
        if self.custom:
            return self.spawn
        index = min(range(len(self.centerline)),
                    key=lambda i:(position.x-self.centerline[i].x)**2+(position.y-self.centerline[i].y)**2)
        point = self.centerline[index]
        return Point3(point.x,point.y,point.z+1.0), self._heading(self._tangent(index))
