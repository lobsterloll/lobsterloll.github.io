"""External glTF/GLB/BAM/OBJ loading and hierarchy-based surface labels."""
import logging
from panda3d.core import Filename
from .config import ASSETS, SURFACES

log = logging.getLogger(__name__)


def load_optional(loader, stem):
    for extension in (".glb", ".gltf", ".bam", ".obj"):
        path = ASSETS / (stem + extension)
        if not path.exists():
            continue
        try:
            model = loader.loadModel(Filename.fromOsSpecific(str(path)), okMissing=True)
            if model is not None and not model.isEmpty():
                log.info("Loaded %s", path.name)
                return model
        except Exception as exc:
            log.warning("Could not import %s: %s", path.name, exc)
        log.warning("Could not load %s; trying another format or primitives", path.name)
    return None


def surface_of(path, root):
    """Use a surface tag, object-name prefix, or material-name prefix.

    Blender objects named grass_infield / dirt_runoff / asphalt_road work
    without engine-specific metadata. Split mixed-material ground into objects.
    """
    node = path
    while not node.isEmpty():
        tag = node.getTag("surface").lower()
        if tag in SURFACES:
            return tag
        name = node.getName().lower()
        for key in SURFACES:
            if name == key or name.startswith(key + "_"):
                return key
        if node == root:
            break
        node = node.getParent()
    if path.hasMaterial():
        name = path.getMaterial().getName().lower()
        for key in SURFACES:
            if name == key or name.startswith(key + "_"):
                return key
    return "asphalt"
