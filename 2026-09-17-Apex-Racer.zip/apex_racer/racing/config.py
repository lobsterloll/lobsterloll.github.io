"""Game units: metres, kilograms, seconds; Z up and local +Y forward."""
from dataclasses import dataclass
from pathlib import Path
from panda3d.core import BitMask32

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
WORLD_MASK = BitMask32.bit(0) | BitMask32.bit(1)
CAR_MASK = BitMask32.bit(1)
RAY_MASK = BitMask32.bit(0)  # Queries see track and walls, never the car itself.
FIXED_DT = 1 / 120


@dataclass(frozen=True)
class Surface:
    label: str
    grip: float  # Bullet frictionSlip tuning value, NOT a literal friction coefficient.
    rolling: float  # Ground resistance in newtons per m/s.
    drive_factor: float


SURFACES = {
    "asphalt": Surface("ASPHALT", 2.85, 18.0, 1.0),
    "grass": Surface("SLIPPERY GRASS", 0.65, 180.0, 0.55),
    "dirt": Surface("SLIPPERY DIRT", 0.9, 115.0, 0.65),
    "wall": Surface("BARRIER", 1.0, 18.0, 1.0),
}


@dataclass(frozen=True)
class CarTuning:
    mass: float = 1150.0
    engine_force: float = 8500.0  # Total rear-axle launch force, N; increase for acceleration.
    engine_power: float = 155000.0  # Watts; F=P/v gives a falling high-speed force curve.
    reverse_force: float = 3000.0
    brake: float = 72.0  # Wheel brake torque: low enough to avoid suspension flip-over.
    brake_rise: float = 3.4  # Pressure builds quickly but without an instant lock-up.
    brake_release: float = 5.0  # Pressure fades before reverse engages.
    brake_front_bias: float = 1.14  # Front axle does more braking, keeping the rear stable.
    brake_deceleration: float = 10.5  # m/s² peak service-brake deceleration at the chassis centre.
    brake_stability: float = 5.8  # Side-slip damping (s^-1) while service braking.
    traction_stability: float = 1.45  # Gentle lateral damping while driving normally.
    engine_braking: float = 520.0  # N of coast-down force with no pedal input.
    handbrake: float = 110.0
    handbrake_grip_factor: float = 0.12  # Rear grip immediately falls to 12% while held.
    max_forward_speed: float = 58.0  # Soft power taper in m/s; no velocity clamping.
    max_reverse_speed: float = 9.0
    aerodynamic_drag: float = 0.42  # Force = coefficient * speed^2.
    steering_low: float = 30.0  # Degrees at parking speed.
    steering_high: float = 9.0  # Degrees at 180 km/h.
    steering_rate: float = 95.0  # Degrees per second, including return to centre.
    wheel_radius: float = 0.36
    suspension_stiffness: float = 32.0
    roll_influence: float = 0.13  # Higher values transfer more tire force into body roll.


TUNING = CarTuning()
