"""Application composition and bounded fixed-step physics loop."""
from panda3d.core import (loadPrcFileData, AmbientLight, DirectionalLight, Vec4,
                          Vec3, ClockObject, Fog)
from panda3d.bullet import BulletWorld
from direct.showbase.ShowBase import ShowBase
from .config import FIXED_DT
from .track import Track
from .car import Car
from .race import RaceManager
from .presentation import Controls, ChaseCamera, HUD


class RacingGame(ShowBase):
    def __init__(self,headless=False,offscreen=False):
        loadPrcFileData("racer","window-title APEX | Python Racing\nwin-size 1280 800\n"
                        "sync-video true\naudio-library-name null\nframebuffer-multisample 1\n"
                        "multisamples 4\nmodel-cache-dir\n")
        super().__init__(windowType="none" if headless else "offscreen" if offscreen else None)
        self.disableMouse()
        self.headless=headless
        self.world=BulletWorld()
        self.world.setGravity(Vec3(0,0,-9.81))
        self.track=Track(self.render,self.loader,self.world)
        self.car=Car(self.render,self.loader,self.world,self.track)
        self.controls=Controls(self)
        self.race=RaceManager(self.track.gates,self.car.position)
        self.accumulator=0.0
        self.chase=None
        self.hud=None
        if not headless:
            self.aspect2d.setDepthTest(False)
            self.aspect2d.setDepthWrite(False)
            self.setBackgroundColor(0.30,0.48,0.66,1)
            self.camLens.setNearFar(0.1,600)
            self.camLens.setFov(64)
            ambient=AmbientLight("ambient")
            ambient.setColor(Vec4(0.14,0.17,0.21,1))
            self.render.setLight(self.render.attachNewNode(ambient))
            sunlight=DirectionalLight("sun")
            sunlight.setColor(Vec4(1.55,1.38,1.12,1))
            # Higher-resolution, tighter shadow coverage keeps the car and
            # nearby barriers crisp while retaining a practical frame rate.
            sunlight.setShadowCaster(True,4096,4096)
            sunlight.getLens().setFilmSize(190,190)
            sunlight.getLens().setNearFar(5,300)
            light=self.render.attachNewNode(sunlight)
            light.setPos(90,-130,190)
            light.lookAt(0,0,0)
            self.render.setLight(light)
            sky_fill=DirectionalLight("sky_fill")
            sky_fill.setColor(Vec4(0.36,0.48,0.66,1))
            fill_node=self.render.attachNewNode(sky_fill)
            fill_node.setPos(-70,90,120)
            fill_node.lookAt(0,0,0)
            self.render.setLight(fill_node)
            fog=Fog("distance_haze")
            fog.setColor(0.30,0.48,0.66)
            fog.setExpDensity(0.0008)
            self.render.setFog(fog)
            import simplepbr
            self.pipeline=simplepbr.init(render_node=self.render,window=self.win,
                                         camera_node=self.cam,taskmgr=self.taskMgr,
                                         msaa_samples=4,enable_shadows=True,
                                         shadow_bias=0.0008,enable_fog=True,exposure=0.92,
                                         use_normal_maps=False,use_emission_maps=False,
                                         use_occlusion_maps=False)
            self.chase=ChaseCamera(self,self.car,self.world)
            self.hud=HUD(self,self.track)
            self.update_presentation(1)
            self.accept("window-event",self.window_event)
            self.window_event(self.win)
        self.accept("r",self.reset_car)
        self.accept("escape",self.userExit)
        self.taskMgr.add(self.frame,"racing-frame")

    def reset_car(self):
        self.car.reset(*self.track.reset_pose(self.car.position))
        self.controls.keys.clear()
        self.race.reset_position(self.car.position)
        if self.chase:
            self.chase.snap=True

    def simulate(self,dt=FIXED_DT):
        self.car.update(dt,self.controls)
        self.world.doPhysics(dt,0)  # The outer loop owns the fixed timestep.
        self.race.update(self.car.position,dt,self.track.on_course(self.car.position))
        if self.car.position.z < -30:
            self.reset_car()

    def update_presentation(self,dt):
        if self.chase:
            self.chase.update(dt)
            self.hud.update(self.car,self.race)

    def window_event(self, window):
        """Preserve the camera's proportions after resize or fullscreen changes."""
        if window is None:
            return
        if hasattr(window,"getProperties"):
            properties = window.getProperties()
            width, height = properties.getXSize(), properties.getYSize()
        else:  # Screenshot mode uses a GraphicsBuffer rather than a window.
            width, height = window.getXSize(), window.getYSize()
        if width > 0 and height > 0:
            self.camLens.setAspectRatio(width / height)

    def frame(self,task):
        # Limit catch-up work after a stall. Race time follows physics time.
        dt=min(ClockObject.getGlobalClock().getDt(),0.10)
        self.accumulator+=dt
        while self.accumulator>=FIXED_DT:
            self.simulate()
            self.accumulator-=FIXED_DT
        self.update_presentation(dt)
        return task.cont

    def destroy(self):
        self.taskMgr.remove("racing-frame")
        self.ignoreAll()
        if hasattr(self,"car"):
            # Bullet removes the chassis together with the vehicle.
            self.world.removeVehicle(self.car.vehicle)
        if hasattr(self,"track"):
            for body in self.track.bodies:
                self.world.removeRigidBody(body.node())
        super().destroy()
