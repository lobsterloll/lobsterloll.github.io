# APEX — Python 3D racing

A runnable, modular single-car time-trial game using Panda3D and its bundled
Bullet physics engine. No art downloads are required. Drive a varied club
circuit with sweepers, a hairpin and esses, and improve your lap.

Includes rear-wheel drive, four raycast suspension wheels, body roll, force-based
acceleration and drag, brake-to-reverse controls, per-wheel terrain grip,
rear-wheel handbrake, static mesh collisions, a chase camera, and a timing HUD.
The scene uses tiled photoreal asphalt and grass assets, PBR material
response, tone mapping, anisotropic filtering, distance haze, and 2048px dynamic
shadows. Its default vehicle is an original rounded GT car with smooth,
hand-authored body sections, animated wheels, a canopy, diffuser, and wing.

This is a tested game foundation, with production-oriented separation of concerns.
Bullet's raycast tires are a simplified driving model, not a Pacejka tire model
or engineering-grade vehicle simulator. There are no AI opponents, sound,
networking, menus, or persistent records in this scope. Best/last times last for
the current session. Validate handling and performance with your final assets
and target hardware before shipping.

## 1. Install Python

Install **64-bit Python 3.12** from https://www.python.org/downloads/.
On Windows, include the Python launcher when installing. These dependencies
were tested here on Windows with Python 3.12, Panda3D 1.10.16, and
panda3d-gltf 1.3.0.

## 2. Extract and open the project

Extract `apex_racer.zip`. Open a terminal in the `apex_racer` folder containing
`main.py` and `requirements.txt`. Do not run Python from inside the ZIP archive.

```text
apex_racer/
  main.py                  Application entry point
  requirements.txt         Tested direct dependency versions
  README.md                This guide
  preview.png              Rendered fallback scene
  assets/
    textures/              Seamless asphalt and grass material tiles
    car.example.json       Optional orientation/size settings example
    track.example.json     Track spawn/checkpoint settings example
  racing/
    config.py              Physics tuning, surface profiles, collision masks
    geometry.py            Procedural car, wheels, road and barriers
    assets.py              Optional model loading and surface identification
    track.py               Circuit generation, static colliders, reset points
    car.py                 Chassis, suspension, grip, propulsion and brakes
    race.py                Directional gates, lap validation and timing
    presentation.py        Input, chase camera and HUD
    game.py                Scene setup and fixed-step simulation loop
  tests/
    test_assets.py         Actual OBJ/glTF import and collider checks
    test_racing.py         Driving, collision and lap behavior checks
```

## 3. Create an isolated environment and install

Windows PowerShell (activation is unnecessary):

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

macOS/Linux equivalent, with Python 3.12 installed:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Panda3D already bundles Bullet. Do not install a second physics engine or
PyBullet for this project. The glTF dependency supplies a model loader.

## 4. Start driving

```powershell
.\.venv\Scripts\python.exe main.py
```

On macOS/Linux, use `.venv/bin/python main.py`.

| Key | Action |
| --- | --- |
| W / Up | Accelerate; brake first if reversing |
| S / Down | Brake while moving forward; reverse after nearly stopping |
| A / Left | Steer left |
| D / Right | Steer right |
| Space | Rear handbrake and immediate rear grip reduction |
| R | Upright reset onto the circuit; abandon current lap |
| Esc | Exit |

The car starts facing the correct direction just behind the checkered line.
Cross it to start timing. Complete all six gates in order and cross the line
again to record a lap. Gates are logical timing planes, not solid obstacles.
The HUD shows the next gate (1 is start/finish), completed laps, elapsed time,
last/best times, terrain, and speed in km/h.

On the demo circuit, leaving the corridor around the spline invalidates the
lap. Finish the ordered gate sequence to start another attempt, or press R.
The outer barriers leave a grass runoff area. R returns to the nearest point
on the racing surface; imported tracks reset to their
configured spawn. Resetting preserves completed lap records.

To drift, enter a corner at moderate speed, steer, and tap Space; release it
and countersteer to recover. Holding Space also brakes the rear wheels, so it
does not preserve speed indefinitely. Grass makes recovery substantially harder.

## 5. Import your own car

Place one of these inside `assets/`:

```text
assets/car.glb
assets/car.gltf       (keep its referenced .bin and texture files alongside it)
assets/car.obj        (keep its .mtl and textures with the relative paths intact)
```

The loader searches `.glb`, `.gltf`, `.bam`, then `.obj`. Missing or unloadable
files generate a console warning and fall back to primitives. OBJ uses Panda3D's
Assimp importer. If a particular OBJ exporter is incompatible, import it into
Blender and export glTF 2.0 / GLB instead. Only use art you are licensed to use.

The physics car uses **+Y forward, +X right, +Z up**. The glTF loader already
converts glTF's Y-up coordinates into Panda3D's coordinate system. Inspect the
result before applying extra rotation.

If needed, copy `assets/car.example.json` to `assets/car.json`:

```json
{
  "hpr": [180, 0, 0],
  "length": 3.9
}
```

`hpr` is heading, pitch, roll in degrees. This example reverses a backward-facing
mesh. The importer rotates the mesh, uniformly fits its longitudinal bounds to
`length` metres, centres it horizontally, and places its bottom at the chassis
visual origin. Adjust `Car.load_visual()` for models with unusual origins.

For animated wheels, export the car **body shell without wheels**. Four
procedural tire meshes already follow Bullet's steering and suspension. A
complete car model will otherwise display its baked wheels alongside the
physics wheels. The dynamic collision shape remains a stable chassis box;
changing the artwork does not silently alter physics. To change the vehicle's
actual size, also change its box extents, wheel connections, and radius in
`car.py` / `config.py`.


## 6. Import your own track

1. Export the track as `assets/track.glb`, `track.gltf`, `track.bam`, or
   `track.obj`. Include walls and obstacles as geometry in the exported scene.
2. Copy `assets/track.example.json` to `assets/track.json`.
3. Replace its example coordinates with positions for **your** circuit.
   If metadata is absent or invalid, the whole track falls back to the demo.
4. Use metre-scale geometry, preferably with transforms applied in the authoring
   tool. `scale`, `hpr`, and `position` transform the imported track if needed.
5. Set `spawn.position` above a safe drivable patch. Start approximately one metre
   above road height and just behind the start line. Heading 0 faces +Y;
   heading +90 faces -X. Spawn and gates are in **final world coordinates**,
   after model transforms, and are not multiplied by `scale` again.
6. Gate 0 is the start/finish line. Add at least two more gates, in driving order;
   use more around complex corners or potential shortcuts. Each `forward`
   vector points in the legal horizontal travel direction through that gate.
   `half_width` is the allowed lateral distance in metres; optional
   `half_height` defaults to 3 metres. Gate centers should match the road height.

Example gate on a road running toward +Y:

```json
{"center": [60, 0, 0], "forward": [0, 1, 0], "half_width": 9, "half_height": 3}
```

`Track.collider()` copies each geometry node into a static
`BulletTriangleMeshShape`, preserving nested transforms. This provides actual
solid road, wall and obstacle collisions; rendered meshes alone do not collide.
For reliable high-speed collisions, give barriers thickness rather than using
single, infinitely thin visual planes. The chassis also uses continuous
collision detection to reduce tunnelling.

Use modest-resolution collision geometry. This version uses the same geometry
for visuals and collisions; for a large production circuit, extend
`Track.load_custom()` to load a separate simplified collision mesh. Avoid
exporting millions of decorative triangles as collision geometry. A Panda node
tag `no_collision=1` on a node or ancestor excludes it from collider creation.

Custom circuits validate gate order and direction. The procedural demo's
spline-distance check does not apply to arbitrary imported tracks: add densely
placed gates or extend `Track.on_course()` with course-specific legal zones.
Metadata must be authored; an arbitrary downloaded model cannot reveal its
intended finish line or race direction automatically.

### Label terrain materials

Split the drivable mesh into objects with these name prefixes:

```text
asphalt_main_road
grass_infield
dirt_runoff
wall_barrier
```

`surface_of()` searches the geometry node and its parents. Explicit Panda node
tags such as `surface=grass` take precedence. A material-name prefix is a
secondary fallback when a material is attached to the node; object prefixes are
the dependable cross-format method. Unknown surfaces default to asphalt.

Split mixed-material ground objects into separate named objects before export;
the collider's surface label applies to the whole geometry node, not individual
triangles. Color alone does not identify grass. Drive over a boundary and check
the HUD; the underlying rays query the actual colliders beneath each wheel.

## 7. Tune the handling

Edit `racing/config.py`. Explanatory comments are next to the parameters.

| Parameter | Effect |
| --- | --- |
| `engine_force` | Rear axle launch force; higher gives stronger low-speed acceleration |
| `engine_power` | High-speed power limit in watts; force falls approximately as power/speed |
| `mass` | Chassis mass; affects acceleration and suspension loading |
| `SURFACES[...].grip` | Bullet tire grip tuning; lower makes that surface slippery |
| `rolling` | Surface resistance proportional to speed; grass slows the car through force |
| `drive_factor` | Available propulsion fraction on each surface |
| `handbrake_grip_factor` | Fraction of rear grip while Space is held; front grip is preserved |
| `brake`, `handbrake` | Bullet per-wheel braking settings, not engine-force units |
| `brake_rise`, `brake_release` | How progressively S builds and releases normal brake pressure |
| `max_forward_speed` | Soft power taper near the limit, in metres/second |
| `steering_low/high` | Steering lock at low/high speed, in degrees |
| `steering_rate` | Steering buildup and self-centering rate for keyboard inputs |
| `suspension_stiffness` | Spring response; retune when changing mass |
| `roll_influence` | How strongly tire forces roll the chassis |

FrictionSlip values are Bullet tuning parameters, not measured rubber-road
coefficients. They reduce both lateral and longitudinal tire traction. This
implementation deliberately reduces rear grip on Space to permit skidding;
it is not a detailed tire-temperature, wear, differential or ABS simulation.

Acceleration is limited by both launch force and engine power, with smooth
throttle buildup. Aero drag and ground resistance oppose motion. The code never
assigns a top-speed velocity or rotates the chassis directly to steer; momentum,
collisions, yaw and body tilt are solved by Bullet. Only resetting teleports it.
Four suspension rays sample surfaces independently, so putting two wheels on
grass changes those tires' grip even while the other tires remain on asphalt.

The physics loop runs at 120 Hz with bounded catch-up after stalls. Rendering and
camera smoothing are separate. Lap timing follows simulation time so physics
and race results remain consistent when frames stall. Focus loss clears keys.

## 8. Run checks

From the project directory:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe main.py --headless --steps 1200
.\.venv\Scripts\python.exe main.py --screenshot preview.png --steps 240
```

The 15 included tests passed in the supplied environment. They cover actual
OBJ/glTF loading, nested mesh transforms, surface labeling, acceleration,
brake-to-reverse behavior, grass grip, rear-only handbrake grip, steering direction,
barrier collision, reset state, input aliases, and lap validation.
Run physics tests before installing custom assets: they assume the demo circuit.
The asset tests use temporary fixtures, not your own asset files.

An offscreen preview was rendered and visually inspected. These checks do not
replace interactive driving and handling adjustment on your target hardware.

## Troubleshooting

- **`py` is missing:** install Python 3.12 and its launcher, or replace
  `py -3.12` with the path to that interpreter. The virtual environment commands
  deliberately avoid PowerShell activation/execution-policy problems.
- **Missing Panda3D:** install requirements with the same environment's Python
  executable you use to run `main.py`.
- **Wrong model orientation:** adjust `car.json` or track `hpr`, then verify +Y
  forward and +Z up. The glTF loader has already performed axis conversion.
- **Missing textures:** retain the model's relative texture paths. GLB can embed
  textures. Advanced PBR materials/extensions may need a dedicated rendering
  pipeline; this game uses Panda3D's basic lighting.
- **Falls through custom road:** inspect exported triangle geometry, spawn height,
  transforms and normals. Check the console for a fallback warning.
- **Track loads but laps do not count:** verify gate centers, widths, height and
  `forward` directions in world coordinates. Gate order matters.
- **GPU/offscreen warning:** some drivers do not support the requested 4x MSAA
  for offscreen buffers; Panda3D can render without it. Use the normal game window
  for play. Update graphics drivers if window creation itself fails.

## Primary engine references

- [Panda3D Bullet vehicle setup and limitations](https://docs.panda3d.org/1.10/python/programming/physics/bullet/vehicles)
- [Bullet static collision shapes](https://docs.panda3d.org/1.10/python/programming/physics/bullet/collision-shapes)
- [Panda3D glTF loader installation](https://docs.panda3d.org/1.10/python/pipeline/gltf-files)
- [panda3d-gltf source](https://github.com/Moguri/panda3d-gltf)
