"""Actual OBJ/glTF imports, transformed triangle collisions and fallback."""
import base64
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch
from panda3d.core import Point3, NodePath
from panda3d.bullet import BulletWorld
from direct.showbase.ShowBase import ShowBase
from racing.assets import load_optional
from racing.track import Track


class AssetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=ShowBase(windowType="none")

    @classmethod
    def tearDownClass(cls):
        cls.app.destroy()

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.folder=Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)

    def test_missing_model_returns_none(self):
        with patch("racing.assets.ASSETS",self.folder):
            self.assertIsNone(load_optional(self.app.loader,"car"))

    def test_obj_import(self):
        (self.folder/"car.obj").write_text("o chassis\nv -1 -2 0\nv 1 -2 0\nv 0 2 1\nf 1 2 3\n")
        with patch("racing.assets.ASSETS",self.folder):
            model=load_optional(self.app.loader,"car")
            self.assertIsNotNone(model)
            self.assertGreater(model.findAllMatches("**/+GeomNode").getNumPaths(),0)
            model.removeNode()

    def test_gltf_nested_transform_surface_and_collision(self):
        # glTF uses Y-up; loader converts its XZ plane into Panda's XY ground.
        positions=[-1,0,-1, 1,0,-1, 1,0,1, -1,0,1]
        binary=struct.pack("<12f6H",*positions,0,2,1,0,3,2)
        scene={"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],
               "nodes":[{"name":"offset_parent","translation":[10,0,0],"scale":[2,2,2],"children":[1]},
                        {"name":"grass_test","mesh":0}],
               "meshes":[{"primitives":[{"attributes":{"POSITION":0},"indices":1}]}],
               "buffers":[{"byteLength":len(binary),"uri":"data:application/octet-stream;base64,"+base64.b64encode(binary).decode()}],
               "bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":48,"target":34962},
                              {"buffer":0,"byteOffset":48,"byteLength":12,"target":34963}],
               "accessors":[{"bufferView":0,"componentType":5126,"count":4,"type":"VEC3","min":[-1,0,-1],"max":[1,0,1]},
                            {"bufferView":1,"componentType":5123,"count":6,"type":"SCALAR"}]}
        (self.folder/"track.gltf").write_text(json.dumps(scene))
        metadata={"position":[5,0,0],"scale":1.5,"spawn":{"position":[20,0,1],"heading":0},
                  "gates":[{"center":[20,y,0],"forward":[0,1,0]} for y in (0,1,2)]}
        (self.folder/"track.json").write_text(json.dumps(metadata))
        world=BulletWorld()
        render=NodePath("test_render")
        with patch("racing.assets.ASSETS",self.folder),patch("racing.track.ASSETS",self.folder):
            track=Track(render,self.app.loader,world)
            self.assertTrue(track.custom)
            self.assertEqual(track.surface_at(Point3(20,0,5),Point3(20,0,-5)),"grass")
            self.assertIsNone(track.surface_at(Point3(0,0,5),Point3(0,0,-5)))
        for body in track.bodies:
            world.removeRigidBody(body.node())
        render.removeNode()


if __name__=="__main__":
    unittest.main()
