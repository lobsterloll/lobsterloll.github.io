"""Behavior tests run real Bullet physics without creating a window."""
import math
import unittest
from panda3d.core import Point3, Vec3
from racing.game import RacingGame
from racing.race import RaceManager, Gate
from racing.config import SURFACES, TUNING


class PhysicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.game=RacingGame(headless=True)

    @classmethod
    def tearDownClass(cls):
        cls.game.destroy()

    def setUp(self):
        self.game.controls.keys.clear()
        self.game.car.reset(*self.game.track.spawn)
        self.step(1)

    def step(self,seconds):
        for _ in range(round(seconds*120)):
            self.game.simulate()

    def test_acceleration_brake_and_reverse(self):
        car=self.game.car
        self.game.controls.keys.add("w")
        self.step(1.5)
        self.assertGreater(car.forward_speed,5)
        speed=car.forward_speed
        self.game.controls.keys={"s"}
        self.step(0.05)
        self.assertGreater(car.brake_input,0)
        self.assertLess(car.brake_input,0.2)
        self.step(0.35)
        self.assertLess(car.forward_speed,speed*0.6)
        self.step(1.5)
        self.assertLess(car.forward_speed,-1)

    def test_grass_reduces_acceleration_and_grip(self):
        car=self.game.car
        self.game.controls.keys={"w"}
        self.step(1.4)
        asphalt_speed=car.forward_speed
        car.reset(Point3(0,0,1),0)
        self.game.controls.keys.clear()
        self.step(1)
        self.game.controls.keys={"w"}
        self.step(1.4)
        self.assertEqual(car.surface,"SLIPPERY GRASS")
        self.assertLess(car.forward_speed,asphalt_speed*0.8)
        self.assertAlmostEqual(car.wheels[0].getFrictionSlip(),SURFACES["grass"].grip,places=5)

    def test_handbrake_only_reduces_rear_grip_and_restores(self):
        self.game.controls.keys={"space"}
        self.step(0.02)
        # Read fresh wrappers from Bullet, rather than checking our cached values.
        wheels=[self.game.car.vehicle.getWheel(i) for i in range(4)]
        self.assertAlmostEqual(wheels[0].getFrictionSlip(),SURFACES["asphalt"].grip,places=5)
        self.assertAlmostEqual(wheels[2].getFrictionSlip(),SURFACES["asphalt"].grip*TUNING.handbrake_grip_factor,places=5)
        self.game.controls.keys.clear()
        self.step(0.02)
        self.assertAlmostEqual(wheels[2].getFrictionSlip(),SURFACES["asphalt"].grip,places=5)

    def test_left_steering_turns_car_left(self):
        car=self.game.car
        initial_heading=car.node.getH()
        self.game.controls.keys={"w","a"}
        self.step(1.6)
        heading_change=(car.node.getH()-initial_heading+180)%360-180
        self.assertGreater(heading_change,3)

    def test_outer_wall_blocks_chassis(self):
        car=self.game.car
        track=self.game.track
        index=48
        center=track.centerline[index]
        tangent=track._tangent(index)
        right=Vec3(tangent.y,-tangent.x,0)
        car.reset(center+right*(track.road_half_width+1)+Vec3(0,0,1.1),track._heading(tangent))
        self.step(0.5)
        car.body.setLinearVelocity(right*16)
        self.step(1.5)
        self.assertLess((car.position-center).dot(right),track.road_half_width+3.8)

    def test_guardrail_collider_matches_visible_inner_face(self):
        track=self.game.track
        index=48
        center=track.centerline[index]
        tangent=track._tangent(index)
        right=Vec3(tangent.y,-tangent.x,0)
        start=center+right*track.road_half_width+Vec3(0,0,0.6)
        end=center+right*(track.road_half_width+6)+Vec3(0,0,0.6)
        hit=self.game.world.rayTestClosest(start,end)
        self.assertTrue(hit.hasHit())
        self.assertEqual(hit.getNode().getPythonTag("surface"),"wall")
        offset=(hit.getHitPos()-center).dot(right)
        self.assertAlmostEqual(offset,track.road_half_width+3.2,delta=0.18)

    def test_reset_clears_motion_and_abandons_lap(self):
        car=self.game.car
        car.node.setHpr(45,170,80)
        car.body.setLinearVelocity(Vec3(10,5,2))
        self.game.race.started=True
        self.game.race.elapsed=20
        self.game.reset_car()
        self.assertLess(car.body.getLinearVelocity().length(),0.001)
        self.assertAlmostEqual(car.node.getR(),0)
        self.assertAlmostEqual(car.node.getP(),0)
        self.assertFalse(self.game.race.started)

    def test_simultaneous_aliases_do_not_release_each_other(self):
        controls=self.game.controls
        controls.set_key("w",True)
        controls.set_key("arrow_up",True)
        controls.set_key("w",False)
        self.assertTrue(controls.held("forward"))


class LapTests(unittest.TestCase):
    def setUp(self):
        self.gates=[Gate(Point3(10*math.cos(a),10*math.sin(a),0),
                         Vec3(-math.sin(a),math.cos(a),0),2)
                    for a in (0,math.pi/2,math.pi,3*math.pi/2)]
        self.race=RaceManager(self.gates,Point3(10,-1,0))

    def cross(self,index,forward=True,on_course=True):
        gate=self.gates[index]
        delta=gate.forward*(1 if forward else -1)
        self.race.previous=gate.center-delta
        self.race.update(gate.center+delta,1,on_course)

    def test_ordered_lap(self):
        for index in (0,1,2,3,0):
            self.cross(index)
        self.assertEqual(self.race.completed,1)
        self.assertEqual(self.race.best,4)

    def test_reverse_and_skipped_gates_rejected(self):
        self.cross(0,False)
        self.assertFalse(self.race.started)
        for index in (0,2,3,0):
            self.cross(index)
        self.assertEqual(self.race.completed,0)
        self.assertEqual(self.race.next_gate,1)

    def test_off_course_lap_invalid(self):
        for index in (0,1,2,3):
            self.cross(index,on_course=index!=2)
        self.cross(0)
        self.assertEqual(self.race.completed,0)
        self.assertTrue(self.race.valid)

    def test_gate_width_height_and_fast_crossing(self):
        gate=self.gates[0]
        self.assertFalse(gate.crossed(Point3(20,-1,0),Point3(20,1,0)))
        self.assertFalse(gate.crossed(Point3(10,-1,9),Point3(10,1,9)))
        self.assertTrue(gate.crossed(Point3(10,-10,0),Point3(10,10,0)))


if __name__=="__main__":
    unittest.main()
